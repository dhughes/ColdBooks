JavaLoader v1.0 Alpha
Author: Mark Mandel
Date: 31 August 2009

Documentation can now be found at:
http://www.compoundtheory.com/javaloader/docs/